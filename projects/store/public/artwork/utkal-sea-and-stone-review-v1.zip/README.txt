UTKAL — SEA & STONE / DESIGN REVIEW v1
Creative direction: Ahimanikya Satapathy. AI-assisted design development.
Not approved for manufacture. Vector studies and rendered mockups differ; reconcile the selected look before vendor proof and sampling.
Four products, only the T-shirt confirmed black. Supplier materials, actual templates, colour matching and pricing are pending.
