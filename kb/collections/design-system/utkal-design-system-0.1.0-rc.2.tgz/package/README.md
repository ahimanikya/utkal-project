# Utkal Design System · 0.1.0-rc.2

Shared colour tokens, scoped CSS components, local fonts and original utility icons for Utkal projects. Implementation candidate; each project adopts a pinned version under its human owner. No automatic deployment or organization-wide adoption.

## Use

Install locally with `npm install ../design-system`, or copy this versioned package with its font licences. Import `@utkal/design-system/styles.css` and wrap the styled area in `class="utk"`. Link the stylesheet at its package location; preserve adjacent font paths when copying. Astro/Vite can resolve the CSS imports and local font assets.

```html
<section class="utk"><div class="utk-wrap utk-stack">
  <h1>Rediscover <em>Utkal.</em></h1>
  <p class="utk-reading">A place. A taste. A story to take with you.</p>
  <button class="utk-button" type="button">Save to my journey</button>
</div></section>
```

Components include buttons, cards, fields, messages, tags, source disclosures, reading blocks, grids and stacks. All selectors for element styling are scoped to `.utk`; no global reset. The prefixed tokens are available outside the scope. Existing projects opt in deliberately.

For icons, import `{icon}` from `@utkal/design-system/icons`. `icon('search')` is decorative beside visible text; `icon('search', {label:'Search'})` is labelled. Give icon-only buttons their own accessible name. No icon conveys a historical assertion.

## Build and review

Node 22+; no dependencies for generation or tests. Run `npm run build`, `npm test`, then `npm run review` after the UTP website build exists. The review generator creates `dist/` with private review pages and copies of the website for local piloting. Serve that folder locally; open `/design-system/`. Never deploy it as the encyclopedia. Only `projects/site/dist` remains the public site artifact.

The gallery saves optional review preferences locally on its own origin and exports JSON. They are recommendations, not recorded publication approval. The three pilots use the same copy and scripts as the source site; storage at the separate review origin does not touch the live site's saved journeys. No CDN, paid service or hosted design tool is needed.

Canonical colours and spacing are in `tokens.json`; `styles/tokens.css` is generated. Change the source, rebuild, inspect and version deliberately. Code compatibility is not visual approval. Shared public components do not include review scripts, layouts or website content.

Created for Ahimanikya Satapathy's Utkal initiative with AI assistance. The system learns from the user-directed Kabita Live design work; no magazine identity or artwork is included. Fonts retain their original project authors and SIL Open Font Licence files in `fonts/`. No broader licence for Utkal identity or artwork is inferred.

## Lessons from the first website adoption

Defaults for links, headings, paragraph margins and images use low specificity. Page adapters retain their image crops and inverse panel colours. Use `.utk-inverse` for a dark surface and `.utk-button--inverse` for a light action on it; an ordinary secondary action is intended for light surfaces. Controls and card children allow intrinsic shrinkage and wrapping. Preserve a readable text measure inside a wide canvas.

UTP imports this sibling package directly at build time; its Git revision pins the source version. The site build regenerates tokens, checks matching versions and includes font licences. Separate repositories should install the exact versioned tarball. Always confirm both CSS-linked fonts and their licences reach the deployment output.

The first adoption includes all 50 website pages, including the standalone photo gallery. Domain-specific photo stages and archive viewers stay in their page adapters. The gallery now displays actual integrated pages; the earlier baseline comparison is historical, not a live toggle. Existing review notes are retained under their version-specific storage keys.
